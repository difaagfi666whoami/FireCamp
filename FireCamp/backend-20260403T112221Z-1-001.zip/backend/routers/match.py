import asyncio
from typing import List
from fastapi import APIRouter, HTTPException
from models import MatchRequest, ProductMatch
from services.match_service import run_matching

router = APIRouter()


@router.post("/match", response_model=List[ProductMatch])
async def match_endpoint(request: MatchRequest):
    """
    POST /api/match
    Body: { "companyProfile": CompanyProfile }
    Returns: ProductMatch[]
    """
    try:
        print(f"\n[Match] === Mulai matching untuk: {request.companyProfile.name} ===")
        results = await asyncio.to_thread(run_matching, request.companyProfile)
        print(f"[Match] === Selesai: {len(results)} hasil ===\n")
        return results
    except Exception as e:
        print(f"[Match] ERROR: {e}")
        raise HTTPException(status_code=500, detail=str(e))
