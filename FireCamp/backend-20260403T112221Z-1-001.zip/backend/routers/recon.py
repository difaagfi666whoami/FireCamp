import asyncio
from fastapi import APIRouter, HTTPException
from models import ReconRequest, CompanyProfile
from services.recon_service import run_recon

router = APIRouter()


@router.post("/recon", response_model=CompanyProfile)
async def recon_endpoint(request: ReconRequest):
    """
    POST /api/recon
    Body: { "url": "https://..." }
    Returns: CompanyProfile JSON
    """
    try:
        print(f"\n[Recon] === Mulai recon untuk URL: {request.url} ===")
        profile = await asyncio.to_thread(run_recon, request.url)
        print(f"[Recon] === Selesai: {profile.name} ===\n")
        return profile
    except Exception as e:
        print(f"[Recon] ERROR: {e}")
        raise HTTPException(status_code=500, detail=str(e))
