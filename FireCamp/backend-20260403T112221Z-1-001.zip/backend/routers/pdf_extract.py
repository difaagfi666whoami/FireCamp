import asyncio
from fastapi import APIRouter, HTTPException, UploadFile, File
from models import PdfExtractionResult
from services.pdf_service import extract_product_from_document

router = APIRouter()

ALLOWED_EXTENSIONS = {"pdf", "docx", "pptx"}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB


@router.post("/pdf-extract", response_model=PdfExtractionResult)
async def pdf_extract_endpoint(file: UploadFile = File(...)):
    """
    POST /api/pdf-extract
    Body: multipart/form-data — field "file" (.pdf / .docx / .pptx, max 10MB)
    Returns: PdfExtractionResult — nama, tagline, deskripsi, harga, USP, confidence
    """
    filename = file.filename or "document"
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Format file tidak didukung: '.{ext}'. Gunakan .pdf, .docx, atau .pptx.",
        )

    file_bytes = await file.read()

    if len(file_bytes) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail="Ukuran file melebihi batas maksimal 10MB.",
        )

    print(f"\n[PdfExtract] === Memproses '{filename}' ({len(file_bytes) // 1024} KB) ===")

    try:
        result = await asyncio.to_thread(
            extract_product_from_document, file_bytes, filename
        )
        print(f"[PdfExtract] === Selesai: '{result.extractedName}' (confidence {result.confidence:.0%}) ===\n")
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        print(f"[PdfExtract] ERROR: {e}")
        raise HTTPException(status_code=500, detail=str(e))
