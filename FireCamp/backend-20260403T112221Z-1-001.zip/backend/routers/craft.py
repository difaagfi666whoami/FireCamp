import asyncio
from fastapi import APIRouter, HTTPException
from models import CraftRequest, Campaign
from services.craft_service import generate_campaign

router = APIRouter()


@router.post("/craft", response_model=Campaign)
async def craft_endpoint(request: CraftRequest):
    """
    POST /api/craft
    Body: { "companyProfile": CompanyProfile, "selectedProduct": ProductCatalogItem }
    Returns: Campaign
    """
    try:
        print(f"\n[Craft] === Mulai craft untuk: {request.companyProfile.name} × {request.selectedProduct.name} ===")
        campaign = await asyncio.to_thread(
            generate_campaign,
            request.companyProfile,
            request.selectedProduct,
        )
        print(f"[Craft] === Selesai: {len(campaign.emails)} email di-generate ===\n")
        return campaign
    except Exception as e:
        print(f"[Craft] ERROR: {e}")
        raise HTTPException(status_code=500, detail=str(e))
