# Campfire AI Engine — Backend FastAPI

AI Processing Engine untuk pipeline **Recon → Match → Craft → PDF Extract**.

**Base URL (local):** `http://localhost:8000`
**Interactive docs:** `http://localhost:8000/docs`

---

## Prasyarat

- Python **3.11+**
- pip

---

## Quick Start

```bash
# 1. Masuk ke folder backend (dari root proyek)
cd backend

# 2. Buat virtual environment
python -m venv .venv

# 3. Aktivasi virtual environment
# Windows:
.venv\Scripts\activate
# Mac / Linux:
source .venv/bin/activate

# 4. Install semua dependencies
pip install -r requirements.txt

# 5. Isi API keys di .env
# File .env sudah ada dengan Supabase pre-filled.
# Isi ANTHROPIC_API_KEY (wajib) + FIRECRAWL_API_KEY + TAVILY_API_KEY
# (edit dengan text editor atau perintah berikut)
# notepad .env     ← Windows
# nano .env        ← Mac/Linux

# 6. Cek status konfigurasi
curl http://localhost:8000/health
# atau buka browser ke http://localhost:8000/health

# 7. Jalankan server (dengan auto-reload saat file berubah)
uvicorn main:app --reload --port 8000
```

---

## Environment Variables

| Variable | Wajib | Keterangan |
|----------|:-----:|------------|
| `ANTHROPIC_API_KEY` | ✅ | Claude AI — dipakai semua endpoint |
| `FIRECRAWL_API_KEY` | Recon | Web scraping website perusahaan |
| `TAVILY_API_KEY` | Recon | News search terbaru perusahaan |
| `SUPABASE_URL` | Match | URL project Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | Match | Service role key (bukan anon key) |

> **Catatan:** Jika `FIRECRAWL_API_KEY` atau `TAVILY_API_KEY` tidak di-set,
> endpoint `/api/recon` tetap berjalan — Claude akan membuat inferensi
> berdasarkan URL saja (kualitas lebih rendah).

---

## Endpoints

| Method | Path | Deskripsi |
|--------|------|-----------|
| `GET` | `/` | Status server |
| `GET` | `/health` | Cek semua API keys terkonfigurasi |
| `POST` | `/api/recon` | Generate company profile dari URL |
| `POST` | `/api/match` | AI product matching vs pain points |
| `POST` | `/api/craft` | Generate 3-email campaign sequence |
| `POST` | `/api/pdf-extract` | Ekstrak info produk dari PDF/DOCX/PPTX |

---

## Contoh Request

### POST /api/recon
```bash
curl -X POST http://localhost:8000/api/recon \
  -H "Content-Type: application/json" \
  -d '{"url": "https://tokopedia.com"}'
```

### POST /api/match
```bash
curl -X POST http://localhost:8000/api/match \
  -H "Content-Type: application/json" \
  -d '{"companyProfile": { ...hasil dari /api/recon... }}'
```

### POST /api/craft
```bash
curl -X POST http://localhost:8000/api/craft \
  -H "Content-Type: application/json" \
  -d '{"companyProfile": {...}, "selectedProduct": {...}}'
```

### POST /api/pdf-extract
```bash
curl -X POST http://localhost:8000/api/pdf-extract \
  -F "file=@/path/to/brosur-produk.pdf"
```

---

## Format Error Response

Semua endpoint mengembalikan error dalam format:
```json
{
  "detail": "Pesan error spesifik dalam Bahasa Indonesia."
}
```

---

## Struktur Folder

```
backend/
├── main.py                    # FastAPI app, CORS, router mounting
├── models.py                  # Pydantic models (cocok dengan TypeScript types/)
├── requirements.txt           # Python dependencies
├── .env                       # API keys (JANGAN di-commit ke git)
├── .env.example               # Template environment variables
├── routers/
│   ├── recon.py               # POST /api/recon
│   ├── match.py               # POST /api/match
│   ├── craft.py               # POST /api/craft
│   └── pdf_extract.py         # POST /api/pdf-extract
└── services/
    ├── recon_service.py        # Firecrawl + Tavily + Claude synthesis
    ├── match_service.py        # Supabase catalog load + Claude matching
    ├── craft_service.py        # Claude 3-email sequence generation
    └── pdf_service.py          # pypdf/docx/pptx + Claude extraction
```
