"""
Campfire AI Engine — FastAPI Backend
Jalankan: uvicorn main:app --reload --port 8000
"""
import os
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Load .env dari folder backend/
load_dotenv()

from routers import recon, match, craft, pdf_extract

app = FastAPI(
    title="Campfire AI Engine",
    description="Backend FastAPI untuk Recon, Match, Craft, dan PDF Extract pipeline.",
    version="1.0.0",
)

# CORS — izinkan Next.js dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(recon.router,       prefix="/api", tags=["Recon"])
app.include_router(match.router,       prefix="/api", tags=["Match"])
app.include_router(craft.router,       prefix="/api", tags=["Craft"])
app.include_router(pdf_extract.router, prefix="/api", tags=["PDF Extract"])


@app.get("/")
def root():
    return {"status": "ok", "message": "Campfire AI Engine is running."}


@app.get("/health")
def health():
    """Cek status API keys yang dibutuhkan."""
    checks = {
        "ANTHROPIC_API_KEY": bool(os.getenv("ANTHROPIC_API_KEY")),
        "FIRECRAWL_API_KEY": bool(os.getenv("FIRECRAWL_API_KEY")),
        "TAVILY_API_KEY": bool(os.getenv("TAVILY_API_KEY")),
        "SUPABASE_URL": bool(os.getenv("SUPABASE_URL")),
        "SUPABASE_SERVICE_ROLE_KEY": bool(os.getenv("SUPABASE_SERVICE_ROLE_KEY")),
    }
    missing = [k for k, v in checks.items() if not v]
    return {
        "status": "degraded" if missing else "healthy",
        "keys": checks,
        "missing": missing,
    }


@app.on_event("startup")
async def startup():
    required = ["ANTHROPIC_API_KEY"]
    missing = [k for k in required if not os.getenv(k)]
    if missing:
        print(f"\n⚠️  WARNING: API keys berikut belum di-set: {', '.join(missing)}")
        print("   Salin backend/.env.example ke backend/.env dan isi nilainya.\n")
    else:
        print("\n✅ Campfire AI Engine siap. Semua API key terkonfigurasi.\n")
