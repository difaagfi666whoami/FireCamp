"""
Pydantic models — struktur 100% cocok dengan TypeScript interfaces di types/*.ts
Gunakan camelCase agar JSON output langsung kompatibel dengan frontend.
"""
from __future__ import annotations
from typing import List, Literal, Optional
from pydantic import BaseModel, Field


# ─── Recon Types (matches types/recon.types.ts) ───────────────────────────────

class LinkedInStats(BaseModel):
    followers: str = "0"
    employees: int = 0
    growth: str = "0%"


class PicContact(BaseModel):
    id: str = ""
    name: str
    title: str = ""
    email: str = ""
    phone: str = ""
    linkedinUrl: Optional[str] = None
    prospectScore: int = 0
    reasoning: str = ""


class PainPoint(BaseModel):
    category: Literal["Marketing", "Operations", "Technology", "Growth"]
    issue: str
    severity: Literal["high", "medium", "low"] = "medium"


class NewsItem(BaseModel):
    title: str
    date: str = ""
    source: str = ""
    summary: str = ""
    url: str = ""


class CampaignProgress(BaseModel):
    recon: bool = True
    match: bool = False
    craft: bool = False
    polish: bool = False
    launch: bool = False
    pulse: bool = False


class CompanyProfile(BaseModel):
    id: str = ""
    url: str
    name: str
    industry: str
    size: str = ""
    founded: str = ""
    hq: str = ""
    description: str = ""
    linkedin: LinkedInStats = Field(default_factory=LinkedInStats)
    contacts: List[PicContact] = []
    painPoints: List[PainPoint] = []
    news: List[NewsItem] = []
    campaignProgress: CampaignProgress = Field(default_factory=CampaignProgress)
    createdAt: str = ""
    cachedAt: str = ""


# ─── Match Types (matches types/match.types.ts) ───────────────────────────────

class ProductCatalogItem(BaseModel):
    id: str
    name: str
    tagline: str = ""
    description: str = ""
    price: str = ""
    painCategories: List[Literal["Marketing", "Operations", "Technology", "Growth"]] = []
    usp: List[str] = []
    source: Literal["manual", "pdf"] = "manual"
    createdAt: str = ""
    updatedAt: str = ""


class ProductMatch(ProductCatalogItem):
    matchScore: int = 0
    addressedPainIndices: List[int] = []
    reasoning: str = ""
    isRecommended: bool = False


# ─── Craft Types (matches types/craft.types.ts) ───────────────────────────────

class CampaignEmail(BaseModel):
    id: str = ""
    sequenceNumber: int
    dayLabel: str
    scheduledDay: int
    subject: str
    body: str
    tone: str = "profesional"
    isApproved: bool = False


class Campaign(BaseModel):
    reasoning: str
    targetCompany: str
    createdAt: str = ""
    emails: List[CampaignEmail]


# ─── Request Bodies ────────────────────────────────────────────────────────────

# ─── PDF Extraction Types (matches types/match.types.ts) ──────────────────────

class PdfExtractionResult(BaseModel):
    extractedName: str = ""
    extractedTagline: str = ""
    extractedDescription: str = ""
    extractedPrice: str = ""
    extractedUsp: List[str] = []
    confidence: float = 0.0


# ─── Request Bodies ────────────────────────────────────────────────────────────

class ReconRequest(BaseModel):
    url: str


class MatchRequest(BaseModel):
    companyProfile: CompanyProfile


class CraftRequest(BaseModel):
    companyProfile: CompanyProfile
    selectedProduct: ProductCatalogItem
