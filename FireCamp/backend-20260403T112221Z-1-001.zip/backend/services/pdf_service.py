"""
PDF/DOCX/PPTX Extraction Service — Claude AI synthesis.
Accepts raw file bytes + filename, extracts product info via Claude.
Dipanggil secara sinkron, di-thread dari FastAPI router.
"""
import io
import json
import os
import re

from anthropic import Anthropic
from models import PdfExtractionResult


# ─── Text Extraction ────────────────────────────────────────────────────────────

def _extract_text_from_pdf(file_bytes: bytes) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(file_bytes))
        pages = [page.extract_text() or "" for page in reader.pages]
        text = "\n".join(pages).strip()
        print(f"[PdfExtract] pypdf: {len(reader.pages)} halaman, {len(text)} chars.")
        return text[:8000]
    except Exception as e:
        print(f"[PdfExtract] pypdf error: {e}")
        return ""


def _extract_text_from_docx(file_bytes: bytes) -> str:
    try:
        import docx
        doc = docx.Document(io.BytesIO(file_bytes))
        text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        print(f"[PdfExtract] docx: {len(doc.paragraphs)} paragraf, {len(text)} chars.")
        return text[:8000]
    except Exception as e:
        print(f"[PdfExtract] python-docx error: {e}")
        return ""


def _extract_text_from_pptx(file_bytes: bytes) -> str:
    try:
        from pptx import Presentation
        prs = Presentation(io.BytesIO(file_bytes))
        texts = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    texts.append(shape.text.strip())
        text = "\n".join(texts)
        print(f"[PdfExtract] pptx: {len(prs.slides)} slide, {len(text)} chars.")
        return text[:8000]
    except Exception as e:
        print(f"[PdfExtract] python-pptx error: {e}")
        return ""


def _extract_text(file_bytes: bytes, filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext == "pdf":
        return _extract_text_from_pdf(file_bytes)
    elif ext == "docx":
        return _extract_text_from_docx(file_bytes)
    elif ext == "pptx":
        return _extract_text_from_pptx(file_bytes)
    raise ValueError(f"Format tidak didukung: .{ext}. Gunakan .pdf, .docx, atau .pptx.")


def _extract_json(text: str) -> str:
    text = text.strip()
    m = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
    if m:
        return m.group(1)
    m = re.search(r'```\s*(.*?)\s*```', text, re.DOTALL)
    if m:
        return m.group(1)
    m = re.search(r'\{.*\}', text, re.DOTALL)
    if m:
        return m.group(0)
    return text


# ─── Main Service ───────────────────────────────────────────────────────────────

def extract_product_from_document(
    file_bytes: bytes,
    filename: str,
) -> PdfExtractionResult:
    """
    Orkestrasi: baca teks dokumen → Claude synthesis → return PdfExtractionResult.
    Raises ValueError untuk input tidak valid, Exception untuk error AI.
    """
    # 1. Extract text dari dokumen
    content = _extract_text(file_bytes, filename)
    if not content.strip():
        raise ValueError(
            "Tidak bisa mengekstrak teks dari dokumen. "
            "Pastikan dokumen bukan gambar scan dan tidak diproteksi password."
        )

    # 2. Prompt Claude
    print(f"[PdfExtract] Prompting Claude untuk ekstraksi dari '{filename}'...")
    client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY", ""))

    prompt = f"""Anda adalah asisten yang bertugas mengekstrak informasi produk atau layanan dari dokumen bisnis.

Nama file: {filename}

Konten dokumen:
{content}

Identifikasi produk atau layanan UTAMA yang dipromosikan dokumen ini, lalu kembalikan HANYA objek JSON valid tanpa teks lain:
{{
  "extractedName": "Nama produk atau layanan utama",
  "extractedTagline": "Tagline atau value proposition singkat (maks. 60 karakter)",
  "extractedDescription": "Deskripsi 2-3 kalimat menjelaskan apa produk/layanan ini dan untuk siapa",
  "extractedPrice": "Harga atau struktur pricing jika ada (kosong string jika tidak tersedia)",
  "extractedUsp": [
    "Keunggulan atau fitur utama 1",
    "Keunggulan atau fitur utama 2",
    "Keunggulan atau fitur utama 3"
  ],
  "confidence": 0.85
}}

Aturan:
- confidence: float 0.0-1.0 — seberapa yakin Anda dengan hasil ekstraksi (berdasarkan kelengkapan info di dokumen)
- extractedUsp: array 2-5 item, masing-masing 1 kalimat pendek
- Semua teks dalam Bahasa Indonesia
- Jika informasi tidak ditemukan, gunakan string kosong "" (bukan null)
- Jangan tambahkan field lain di luar struktur di atas"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )

    raw = message.content[0].text
    print("[PdfExtract] Claude selesai. Parsing JSON...")

    data = json.loads(_extract_json(raw))
    return PdfExtractionResult(**data)
