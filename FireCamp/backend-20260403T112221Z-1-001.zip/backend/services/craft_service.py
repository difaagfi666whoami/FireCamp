"""
Craft Service — Claude generate 3-email drip campaign sequence.
"""
import json
import os
import re
import uuid
from datetime import datetime

from anthropic import Anthropic
from models import Campaign, CampaignEmail, CompanyProfile, ProductCatalogItem


def _extract_json(text: str) -> str:
    text = text.strip()
    m = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
    if m:
        return m.group(1)
    m = re.search(r'```\s*(.*?)\s*```', text, re.DOTALL)
    if m:
        return m.group(1)
    m = re.search(r'\{.*\}', text, re.DOTALL)
    if m:
        return m.group(0)
    return text


def generate_campaign(company: CompanyProfile, product: ProductCatalogItem) -> Campaign:
    """
    Generate 3-email sequence menggunakan Claude.
    Dipanggil secara sinkron, di-thread dari FastAPI router.
    """
    pain_text = "\n".join(
        f"- [{p.category}] {p.issue} (severity: {p.severity})"
        for p in company.painPoints
    )
    news_text = "\n".join(
        f"- {n.title} ({n.date}, {n.source}): {n.summary}"
        for n in company.news[:2]
    )
    usp_text = "\n".join(f"- {u}" for u in product.usp)

    print(f"[Craft] Prompting Claude untuk generate campaign email untuk {company.name}...")
    client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY", ""))

    now = datetime.now().isoformat()
    prompt = f"""Anda adalah copywriter B2B sales berpengalaman. Buat 3-email drip campaign sequence yang sangat personal.

Target Perusahaan: {company.name}
Industri: {company.industry}
Deskripsi: {company.description}
Lokasi HQ: {company.hq}

Pain Points:
{pain_text}

Berita Terbaru:
{news_text or "Tidak tersedia."}

Produk yang Di-pitch: {product.name}
Tagline: {product.tagline}
Deskripsi: {product.description}
Harga: {product.price}
USP:
{usp_text}

Kembalikan HANYA objek JSON valid tanpa teks lain:
{{
  "reasoning": "2-3 kalimat menjelaskan strategi campaign: mengapa urutan ini dipilih, bagaimana setiap email membangun dari yang sebelumnya, dan mengapa ini relevan untuk {company.name}.",
  "targetCompany": "{company.name}",
  "createdAt": "{now}",
  "emails": [
    {{
      "id": "email-1",
      "sequenceNumber": 1,
      "dayLabel": "Hari ke-1",
      "scheduledDay": 1,
      "subject": "Subject email 1 — referensikan nama perusahaan atau berita terbaru",
      "body": "Isi email lengkap 150-250 kata. Mulai dengan referensi berita/event terbaru {company.name}. JANGAN pitch langsung. Akhiri dengan pertanyaan soft. Gunakan placeholder [Nama] untuk penerima.",
      "tone": "profesional",
      "isApproved": false
    }},
    {{
      "id": "email-2",
      "sequenceNumber": 2,
      "dayLabel": "Hari ke-4",
      "scheduledDay": 4,
      "subject": "Subject email 2 — fokus pada 1 pain point spesifik",
      "body": "150-250 kata. Fokus SATU pain point dengan data/angka. Perkenalkan produk sebagai solusi. Akhiri dengan CTA soft (bukan hard close).",
      "tone": "profesional",
      "isApproved": false
    }},
    {{
      "id": "email-3",
      "sequenceNumber": 3,
      "dayLabel": "Hari ke-10",
      "scheduledDay": 10,
      "subject": "Subject email 3 — sudut risiko bisnis",
      "body": "150-200 kata. Framing risiko bisnis jika masalah tidak diselesaikan. Low-pressure close dengan opsi jadwal demo/call. Bukan ultimatum.",
      "tone": "profesional",
      "isApproved": false
    }}
  ]
}}

Aturan wajib:
- Semua body email dalam Bahasa Indonesia
- Subject line: spesifik, referensikan nama perusahaan atau pain point
- Email 1 (Ice-breaker): referensi 1 berita terbaru dari data di atas
- Email 2 (Pain-focused): angka spesifik dari pain points, solusi konkret
- Email 3 (Urgency & close): framing risiko, ajakan demo, BUKAN ancaman
- Gunakan [Nama] sebagai placeholder nama penerima
- Setiap email harus bisa berdiri sendiri (anggap penerima belum baca email sebelumnya)"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )

    raw = message.content[0].text
    print("[Craft] Claude selesai. Parsing campaign JSON...")

    data = json.loads(_extract_json(raw))

    # Pastikan semua email punya UUID yang valid
    emails = []
    for e in data.get("emails", []):
        e["id"] = str(uuid.uuid4())
        emails.append(CampaignEmail(**e))

    return Campaign(
        reasoning=data.get("reasoning", ""),
        targetCompany=data.get("targetCompany", company.name),
        createdAt=now,
        emails=emails,
    )
