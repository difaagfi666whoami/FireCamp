"""
Match Service — baca produk dari Supabase + Claude matching.
"""
import json
import os
import re
from typing import List

from anthropic import Anthropic
from models import CompanyProfile, ProductMatch


def _extract_json(text: str) -> str:
    text = text.strip()
    m = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
    if m:
        return m.group(1)
    m = re.search(r'```\s*(.*?)\s*```', text, re.DOTALL)
    if m:
        return m.group(1)
    m = re.search(r'\[.*\]', text, re.DOTALL)
    if m:
        return m.group(0)
    return text


def _load_products_from_supabase() -> list:
    """Baca seluruh produk dari Supabase menggunakan service role key."""
    url = os.getenv("SUPABASE_URL", "")
    key = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")
    if not url or not key:
        print("[Match] SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY tidak di-set.")
        return []
    try:
        from supabase import create_client
        print("[Match] Memuat produk dari Supabase...")
        sb = create_client(url, key)
        response = sb.table("products").select("*").execute()
        products = response.data or []
        print(f"[Match] {len(products)} produk ditemukan di katalog.")
        return products
    except Exception as e:
        print(f"[Match] Supabase error: {e}")
        return []


def _row_to_dict(row: dict) -> dict:
    """Map Supabase snake_case row ke camelCase dict untuk Claude prompt."""
    return {
        "id": row.get("id", ""),
        "name": row.get("name", ""),
        "tagline": row.get("tagline", ""),
        "description": row.get("description", ""),
        "price": row.get("price", ""),
        "painCategories": row.get("pain_categories", []),
        "usp": row.get("usp", []),
    }


def run_matching(company: CompanyProfile) -> List[ProductMatch]:
    """
    Orkestrasi: load products → Claude matching → return ProductMatch[].
    """
    products = _load_products_from_supabase()
    if not products:
        raise ValueError(
            "Katalog produk kosong. Tambah produk terlebih dahulu di tab 'Katalog Produk'."
        )

    pain_text = "\n".join(
        f"[{i}] [{p.category}] {p.issue} (severity: {p.severity})"
        for i, p in enumerate(company.painPoints)
    )
    products_text = json.dumps([_row_to_dict(p) for p in products], ensure_ascii=False)

    print(f"[Match] Prompting Claude untuk match {len(company.painPoints)} pain points vs {len(products)} produk...")
    client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY", ""))

    prompt = f"""Anda adalah B2B sales expert. Cocokkan pain points perusahaan berikut dengan produk yang paling relevan.

Perusahaan: {company.name} ({company.industry})
Deskripsi: {company.description}

Pain Points (indeks 0 sampai {len(company.painPoints) - 1}):
{pain_text}

Katalog Produk (JSON):
{products_text}

Kembalikan HANYA array JSON valid tanpa teks lain, satu entry per produk:
[
  {{
    "productId": "uuid-produk-dari-katalog",
    "matchScore": 87,
    "addressedPainIndices": [0, 2],
    "reasoning": "Penjelasan 2-3 kalimat spesifik mengapa produk ini cocok untuk {company.name}, referensikan pain point nyata.",
    "isRecommended": true
  }}
]

Aturan:
- Sertakan SEMUA produk di katalog dalam array
- matchScore: integer 0-100
- addressedPainIndices: array indeks pain point yang di-address produk ini
- isRecommended: true HANYA untuk 1 produk dengan skor tertinggi
- reasoning dalam Bahasa Indonesia, spesifik ke perusahaan ini
- Urutkan dari matchScore tertinggi ke terendah"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}],
    )

    raw = message.content[0].text
    print("[Match] Claude selesai. Parsing hasil matching...")

    raw_results = json.loads(_extract_json(raw))

    # Map product rows ke dict untuk lookup cepat
    product_map = {p["id"]: p for p in products}

    results: List[ProductMatch] = []
    for r in raw_results:
        prod = product_map.get(r.get("productId", ""))
        if not prod:
            continue
        results.append(ProductMatch(
            id=prod["id"],
            name=prod.get("name", ""),
            tagline=prod.get("tagline", "") or "",
            description=prod.get("description", "") or "",
            price=prod.get("price", "") or "",
            painCategories=prod.get("pain_categories", []),
            usp=prod.get("usp", []),
            source=prod.get("source", "manual"),
            createdAt=prod.get("created_at", ""),
            updatedAt=prod.get("updated_at", ""),
            matchScore=int(r.get("matchScore", 0)),
            addressedPainIndices=r.get("addressedPainIndices", []),
            reasoning=r.get("reasoning", ""),
            isRecommended=bool(r.get("isRecommended", False)),
        ))

    print(f"[Match] Selesai. {len(results)} produk dicocokkan.")
    return results
