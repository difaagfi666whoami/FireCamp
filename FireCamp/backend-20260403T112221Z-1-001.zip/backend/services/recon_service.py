"""
Recon Service — Firecrawl scrape + Tavily news search + Claude synthesis.
Semua IO adalah blocking; dipanggil via asyncio.to_thread dari router.
"""
import json
import os
import re
import uuid
from datetime import datetime

from anthropic import Anthropic
from models import CompanyProfile


# ─── Helper ───────────────────────────────────────────────────────────────────

def _extract_json(text: str) -> str:
    """Ambil JSON dari respons Claude (handles code fences & raw JSON)."""
    text = text.strip()
    m = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
    if m:
        return m.group(1)
    m = re.search(r'```\s*(.*?)\s*```', text, re.DOTALL)
    if m:
        return m.group(1)
    # Cari object JSON terluar
    m = re.search(r'\{.*\}', text, re.DOTALL)
    if m:
        return m.group(0)
    return text


def _scrape_website(url: str) -> str:
    """Scrape website menggunakan Firecrawl. Returns markdown content."""
    api_key = os.getenv("FIRECRAWL_API_KEY", "")
    if not api_key:
        print("[Recon] FIRECRAWL_API_KEY tidak di-set — melewati scraping.")
        return ""
    try:
        from firecrawl import FirecrawlApp
        print(f"[Recon] Scraping {url} via Firecrawl...")
        fc = FirecrawlApp(api_key=api_key)
        result = fc.scrape_url(url, params={"formats": ["markdown"]})
        content = result.get("markdown", "") or ""
        print(f"[Recon] Scraped {len(content)} chars dari {url}")
        return content[:8000]  # batas token
    except Exception as e:
        print(f"[Recon] Firecrawl error: {e}")
        return ""


def _search_news(company_hint: str) -> str:
    """Cari berita terbaru via Tavily API. Returns JSON string."""
    api_key = os.getenv("TAVILY_API_KEY", "")
    if not api_key:
        print("[Recon] TAVILY_API_KEY tidak di-set — melewati news search.")
        return ""
    try:
        from tavily import TavilyClient
        print(f"[Recon] Mencari berita untuk '{company_hint}' via Tavily...")
        client = TavilyClient(api_key=api_key)
        results = client.search(
            query=f"{company_hint} company news 2024 2025",
            search_depth="advanced",
            max_results=5,
        )
        items = results.get("results", [])
        print(f"[Recon] Ditemukan {len(items)} artikel berita.")
        return json.dumps(items, ensure_ascii=False)[:4000]
    except Exception as e:
        print(f"[Recon] Tavily error: {e}")
        return ""


# ─── Main Service ──────────────────────────────────────────────────────────────

def run_recon(url: str) -> CompanyProfile:
    """
    Orkestrasi: scrape → cari berita → Claude synthesis → return CompanyProfile.
    Dipanggil secara sinkron, di-thread dari FastAPI router.
    """
    # 1. Scrape website
    scraped = _scrape_website(url)

    # 2. Cari berita
    company_hint = url.split("//")[-1].split("/")[0].replace("www.", "").split(".")[0]
    news_raw = _search_news(company_hint)

    # 3. Prompt Claude
    print("[Recon] Prompting Claude untuk analisis profil perusahaan...")
    client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY", ""))

    now = datetime.now().isoformat()
    prompt = f"""Anda adalah analis B2B sales berpengalaman. Analisis data perusahaan berikut dan hasilkan profil riset terstruktur dalam format JSON.

URL Target: {url}

Konten Website (markdown):
{scraped or "Tidak tersedia — gunakan URL untuk inferensi detail perusahaan."}

Data Berita Terbaru (JSON dari Tavily):
{news_raw or "Tidak tersedia."}

Kembalikan HANYA objek JSON valid dengan struktur berikut (tanpa teks lain):
{{
  "id": "",
  "url": "{url}",
  "name": "Nama Perusahaan",
  "industry": "Industri",
  "size": "250-500 karyawan",
  "founded": "2015",
  "hq": "Jakarta, Indonesia",
  "description": "Deskripsi 2-3 kalimat tentang perusahaan.",
  "linkedin": {{
    "followers": "12.4K",
    "employees": 300,
    "growth": "+15% YoY"
  }},
  "contacts": [
    {{
      "id": "",
      "name": "Nama Lengkap",
      "title": "VP of Marketing",
      "email": "nama@perusahaan.com",
      "phone": "+62 812-xxxx-xxxx",
      "linkedinUrl": "https://linkedin.com/in/...",
      "prospectScore": 88,
      "reasoning": "Decision maker untuk budget marketing, relevan karena..."
    }}
  ],
  "painPoints": [
    {{
      "category": "Marketing",
      "issue": "Tingkat konversi email campaign hanya 1.2%, jauh di bawah rata-rata industri 3.5%",
      "severity": "high"
    }}
  ],
  "news": [
    {{
      "title": "Judul berita",
      "date": "15 Jan 2025",
      "source": "Nama Sumber",
      "summary": "Ringkasan 1-2 kalimat.",
      "url": "https://source.com/artikel"
    }}
  ],
  "campaignProgress": {{"recon": true, "match": false, "craft": false, "polish": false, "launch": false, "pulse": false}},
  "createdAt": "{now}",
  "cachedAt": "{now}"
}}

Aturan ketat:
- contacts: 2-3 orang dengan prospectScore >= 60 (decision maker / influencer)
- painPoints: 4-5 item dengan angka spesifik, dalam Bahasa Indonesia
- category harus salah satu dari: "Marketing", "Operations", "Technology", "Growth"
- severity: "high" / "medium" / "low"
- news: 2-3 artikel relevan terbaru; gunakan URL nyata dari data Tavily jika tersedia
- Jika data tidak tersedia, buat inferensi masuk akal berdasarkan industri perusahaan"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )

    raw = message.content[0].text
    print("[Recon] Claude selesai. Parsing JSON...")

    data = json.loads(_extract_json(raw))
    data["id"] = str(uuid.uuid4())
    data["createdAt"] = now
    data["cachedAt"] = now

    return CompanyProfile(**data)
